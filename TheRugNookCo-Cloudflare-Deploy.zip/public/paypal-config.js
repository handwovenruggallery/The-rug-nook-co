// PayPal client configuration is supplied securely at runtime by /api/paypal-config.
// Never place PAYPAL_CLIENT_SECRET in this file.
window.PAYPAL_CLIENT_ID = "";
