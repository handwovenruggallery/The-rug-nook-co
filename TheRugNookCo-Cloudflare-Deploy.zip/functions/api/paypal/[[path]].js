import handler from '../../_lib/paypal-api.mjs';
export async function onRequest(context) {
  return handler(context.request, context.env);
}
