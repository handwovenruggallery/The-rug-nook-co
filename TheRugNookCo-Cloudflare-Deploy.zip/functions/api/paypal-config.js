import handler from '../_lib/paypal-config.mjs';
export async function onRequest(context) {
  return handler(context.request, context.env);
}
