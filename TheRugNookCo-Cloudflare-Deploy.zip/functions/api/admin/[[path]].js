import handler from '../../_lib/admin-api.mjs';
export async function onRequest(context) {
  return handler(context.request, context.env);
}
