import handler from '../../_lib/promotions.mjs';
export async function onRequest(context) {
  return handler(context.request, context.env);
}
