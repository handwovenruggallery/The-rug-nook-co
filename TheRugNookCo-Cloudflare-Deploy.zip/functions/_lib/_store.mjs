// Cloudflare KV-backed persistent store. Create a KV namespace and bind it as SHOP_DATA.
export async function read(env, key, fallback) {
  if (!env?.SHOP_DATA) throw new Error('Cloudflare KV binding SHOP_DATA is missing.');
  const value = await env.SHOP_DATA.get(key, { type: 'json' });
  return value == null ? fallback : value;
}
export async function write(env, key, value) {
  if (!env?.SHOP_DATA) throw new Error('Cloudflare KV binding SHOP_DATA is missing.');
  await env.SHOP_DATA.put(key, JSON.stringify(value));
  return value;
}
