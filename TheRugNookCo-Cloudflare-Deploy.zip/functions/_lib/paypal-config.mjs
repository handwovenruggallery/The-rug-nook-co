const json=(b,s=200)=>new Response(JSON.stringify(b),{status:s,headers:{'content-type':'application/json','cache-control':'no-store'}});
export default async (req,env)=>{const clientId=env.PAYPAL_CLIENT_ID||'';return json({configured:!!clientId,clientId,mode:env.PAYPAL_MODE||'sandbox'});};
