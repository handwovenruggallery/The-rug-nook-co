import crypto from 'node:crypto';
import { read, write } from './_store.mjs';
const json=(body,status=200,extraHeaders={})=>new Response(JSON.stringify(body),{status,headers:{'content-type':'application/json','cache-control':'no-store',...extraHeaders}});
const cookieName='trn_admin_session';
function cookieToken(req){const c=req.headers.get('cookie')||'';const m=c.match(new RegExp('(?:^|;\\s*)'+cookieName+'=([^;]+)'));return m?decodeURIComponent(m[1]):'';}
const clearCookie=()=>cookieName+'=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0';
const setCookie=t=>cookieName+'='+encodeURIComponent(t)+'; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=86400';
const hash=s=>crypto.createHash('sha256').update(String(s)).digest('hex');
async function sendEmail(env,to,subject,html){if(!to||!env.RESEND_API_KEY||!env.FROM_EMAIL)return false;const r=await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:'Bearer '+env.RESEND_API_KEY,'Content-Type':'application/json'},body:JSON.stringify({from:env.FROM_EMAIL,to:[to],subject,html})});return r.ok;}
async function auth(req,env){const h=req.headers.get('authorization')||'';const bearer=h.startsWith('Bearer ')?h.slice(7):'';const token=bearer||cookieToken(req);const saved=await read(env,'admin_auth',null);if(!saved||!token||!saved.token)return false;const a=Buffer.from(String(token));const b=Buffer.from(String(saved.token));return a.length===b.length&&crypto.timingSafeEqual(a,b);}
const defaults={email:'handwovenruggallery@gmail.com',shipping:'Free shipping included',processing:'2 weeks',returns:'14 days',contact:'handwovenruggallery@gmail.com',shopName:'The Rug Nook Co',country:'India',currency:'USD',shippingProfile:'Free shipping',policyNote:'Please review product-specific terms before ordering.',reviewPolicy:'Verified website buyers may submit one review per order item.',emailNotifications:true,customerAccounts:false};
export default async (req,env)=>{try{const u=new URL(req.url),action=u.searchParams.get('action')||'get';
 if(req.method==='POST'&&action==='login'){const b=await req.json();const pin=String(b.pin||'').trim();if(!pin)return json({ok:false,error:'PIN required'},400);let saved=await read(env,'admin_auth',null);if(!saved){const initialPin=String(env.ADMIN_PIN||'').trim();if(!initialPin)return json({ok:false,error:'Admin setup is not configured. Set the ADMIN_PIN secret in Cloudflare Pages first.'},503);saved={pinHash:hash(initialPin),token:crypto.randomBytes(32).toString('hex')};await write(env,'admin_auth',saved);}if(saved.pinHash!==hash(pin))return json({ok:false,error:'Incorrect PIN'},401);return json({ok:true},200,{'set-cookie':setCookie(saved.token)});}
 if(req.method==='POST'&&action==='logout'){return json({ok:true},200,{'set-cookie':clearCookie()});}
 if(!(await auth(req,env)))return json({ok:false,error:'Unauthorized'},401);
 if(req.method==='GET'){
  const catalog=await read(env,'catalog',null),orders=await read(env,'orders',[]),settings=await read(env,'settings',defaults),stats=await read(env,'stats',{visits:0,viewsTotal:0,views:{},events:[]}),messages=await read(env,'messages',[]),favorites=await read(env,'favorites',[]),campaigns=await read(env,'campaigns',[]),promotions=await read(env,'promotions',[]),reviews=await read(env,'reviews',[]),notifications=await read(env,'notifications',[]),shippingLabels=await read(env,'shipping_labels',[]),offers=await read(env,'offer_settings',{enabled:false,maxDiscount:20,productIds:[]}),catalogSeeded=await read(env,'catalog_seeded',false);
  return json({ok:true,catalog,orders,settings:{...defaults,...settings},stats,messages,favorites,campaigns,promotions,reviews,notifications,shippingLabels,offers,initialized:catalog!==null,catalogSeeded});
 }
 const b=await req.json();
 if(action==='init'){const existing=await read(env,'catalog',null),seeded=await read(env,'catalog_seeded',false);if(existing===null || (!seeded&&Array.isArray(existing)&&existing.length===0)){await write(env,'catalog',Array.isArray(b.catalog)?b.catalog:[]);await write(env,'settings',{...defaults,...(b.settings||{})});await write(env,'catalog_seeded',true);}return json({ok:true});}
 if(action==='catalog')return json({ok:true,catalog:await write(env,'catalog',Array.isArray(b.catalog)?b.catalog:[])});
 if(action==='orders'){const incoming=Array.isArray(b.orders)?b.orders:[],previous=await read(env,'orders',[]);await write(env,'orders',incoming);if(env.RESEND_API_KEY&&env.FROM_EMAIL){for(const n of incoming.slice(0,50)){const o=previous.find(x=>x.id===n.id);if(o&&o.customer?.email&&(o.status!==n.status||o.trackingNumber!==n.trackingNumber)){const subject=n.trackingNumber?'Shipment update — '+n.id:'Order update — '+n.id;await sendEmail(env,o.customer.email,subject,`<h2>The Rug Nook Co order update</h2><p>Order <b>${n.id}</b> is now <b>${n.status}</b>.</p>${n.trackingNumber?`<p>Tracking: <b>${n.trackingNumber}</b></p>`:''}<p>You can use the order tracking page on our website for the latest status.</p>`);}}}return json({ok:true,orders:incoming});}
 if(action==='preview'){const previewToken=crypto.randomBytes(24).toString('hex');await write(env,'preview_token',{tokenHash:hash(previewToken),expiresAt:Date.now()+10*60*1000});return json({ok:true,previewToken,expiresAt:Date.now()+10*60*1000});}
 if(action==='settings')return json({ok:true,settings:await write(env,'settings',{...defaults,...(b.settings||{})})});
 if(action==='stats')return json({ok:true,stats:await write(env,'stats',b.stats||{})});
 if(action==='messages')return json({ok:true,messages:await write(env,'messages',Array.isArray(b.messages)?b.messages:[])});
 if(action==='favorites')return json({ok:true,favorites:await write(env,'favorites',Array.isArray(b.favorites)?b.favorites:[])});
 if(action==='campaigns')return json({ok:true,campaigns:await write(env,'campaigns',Array.isArray(b.campaigns)?b.campaigns:[])});
 if(action==='promotions')return json({ok:true,promotions:await write(env,'promotions',Array.isArray(b.promotions)?b.promotions:[])});
 if(action==='reviews')return json({ok:true,reviews:await write(env,'reviews',Array.isArray(b.reviews)?b.reviews:[])});
 if(action==='notifications')return json({ok:true,notifications:await write(env,'notifications',Array.isArray(b.notifications)?b.notifications:[])});
 if(action==='shippingLabels')return json({ok:true,shippingLabels:await write(env,'shipping_labels',Array.isArray(b.shippingLabels)?b.shippingLabels:[])});
 if(action==='offers')return json({ok:true,offers:await write(env,'offer_settings',b.offers||{})});
 return json({ok:false,error:'Unknown action'},400);
 }catch(e){return json({ok:false,error:e.message||'Server error'},500)}};
